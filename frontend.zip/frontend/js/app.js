/**
 * FraudShield AI - Simple, Beginner-Friendly & Accessible Client
 * Multi-language support (English & Hindi), Step-by-Step Form, Zero Jargon
 */

const API_BASE = (window.location.protocol === 'file:' || !window.location.origin.includes(':8080'))
    ? 'http://localhost:8080/api'
    : '/api';

// =============================================================================
// BILINGUAL DICTIONARY (Simple English & Natural Hindi)
// =============================================================================
const I18N = {
  en: {
    tagline: "Check for Fraud • Stay Safe",
    navHome: "Home",
    navCheck: "Check Transaction",
    navCheckShort: "Check",
    navHistory: "Previous Checks",
    navHistoryShort: "History",
    navHelp: "Help",
    navAccount: "My Account",
    navAccountShort: "Account",
    navAdmin: "Admin Reports",
    btnSignIn: "Sign In",
    btnSignOut: "Sign Out",
    btnCreateAccount: "Create Account",

    // Home View
    heroChip: "Simple, Safe & Beginner-Friendly",
    homeTitle: "Check If Your Payment Is Safe Before You Send Money",
    homeSubtitle: "Not sure about a payment, shop, or online transfer? Enter a few details to see if it looks safe or suspicious in plain, everyday language.",
    btnCheckAction: "Check a Transaction",
    btnPreviousAction: "See Previous Checks",
    howItWorksTitle: "How Does It Work?",
    howItWorksSubtitle: "It takes only 3 simple steps to check any payment.",
    step1Title: "1. Enter Details",
    step1Desc: "Type in the payment amount and the shop or business name.",
    step2Title: "2. Click Check",
    step2Desc: "Our safety engine looks for common warning signs and unusual patterns.",
    step3Title: "3. See the Result",
    step3Desc: "Get a clear answer: Looks Safe, Be Careful, or Needs Attention.",
    disclaimerTitle: "Always verify payments before sending money:",
    disclaimerText: "FraudShield AI provides a safety estimate to help you spot warning signs. It does not replace your bank's security checks or official advice.",

    // Check Form View
    backHome: "Home",
    checkTitle: "Check a Transaction",
    checkSubtitle: "Fill in the details below. We will check whether anything looks unusual.",
    step1Tab: "1. Basic Details",
    step2Tab: "2. Additional Details (Optional)",
    quickPresetsLabel: "Quick Test Examples:",
    presetSafe: "Safe Grocery ($45)",
    presetMedium: "Unusual Purchase ($750)",
    presetHigh: "Suspicious Transfer ($4,850)",
    lblAmount: "Payment Amount",
    hintAmount: "Enter the amount of money being paid or requested.",
    lblShopName: "Shop, Business, or Person",
    hintShopName: "Who is receiving the payment?",
    quickSelect: "Quick Select:",
    catGrocery: "Grocery",
    catShopping: "Shopping",
    catElectronics: "Electronics",
    catBills: "Bills",
    catTravel: "Travel",
    catCrypto: "Crypto",
    lblDateTime: "When did this happen?",
    hintDateTime: "Defaults to current time. Change if you are checking an earlier payment.",
    btnNextDetails: "Next: Add Details (Optional) →",
    step2Note: "These details help our safety check be more accurate. If you do not know them, you can leave them as default.",
    lblPaymentMethod: "How is the payment being made?",
    optCard: "Debit or Credit Card",
    optUPI: "UPI / Online Instant Transfer / PhonePe / GPay",
    optNetBanking: "Net Banking / Bill Pay",
    optATM: "ATM Cash Withdrawal",
    lblCity: "City or Location",
    hintCity: "Where was this payment made from or requested?",
    lblUsualCity: "Your Usual City or Home Town",
    hintUsualCity: "Used to detect if a payment came from an unexpected city or country.",
    lblDevice: "What device was used?",
    optMyPhone: "My Personal Phone (Familiar Device)",
    optMyComputer: "My Computer or Laptop",
    optNewDevice: "New or Unfamiliar Device",
    lblNewDeviceCheckbox: "This payment was made on a brand new or someone else's device",
    btnBackStep: "← Back to Step 1",
    btnCheckSubmit: "CHECK THIS TRANSACTION",
    checkingProgress: "Checking safety... please wait a few seconds",

    // Result View
    checkAnother: "Check Another Transaction",
    lblReference: "Check Reference:",
    safetyResultLabel: "SAFETY RESULT",
    safeTitle: "LOOKS SAFE",
    safeDesc: "Nothing unusual was found in the details you provided. Always verify payments before confirming them.",
    mediumTitle: "BE CAREFUL",
    mediumDesc: "Some details look unusual. Please check the payment information before continuing.",
    highTitle: "NEEDS ATTENTION",
    highDesc: "This transaction has several warning signs. Do not proceed until you have verified it through your bank or payment provider.",
    safetyScoreTitle: "Safety Score",
    tierSafe: "Looks Safe",
    tierMedium: "Be Careful",
    tierHigh: "Needs Attention",
    scoreExplanation: "A lower score means fewer warning signs were found. A higher score means there are more reasons to be cautious.",
    txnSummaryTitle: "Transaction Details Checked",
    reasonsTitle: "Top Reasons Behind This Result",
    nextStepsTitle: "What Should I Do Next?",
    transparencyNotice: "Notice: This safety score is calculated using standard financial fraud prevention rules. It is an advisory risk estimate and does not guarantee that a payment is 100% safe or fraudulent.",
    btnCheckAnother: "Check Another Transaction",
    btnSeePrevious: "See Previous Checks",
    btnPrint: "Print or Save",
    btnBackHome: "Return Home",

    // Previous Checks View
    historyTitle: "Previous Checks",
    historySubtitle: "Review your previous payment safety checks.",
    btnNewCheck: "New Check",
    searchPlaceholder: "Search by reference or shop name...",
    filterAll: "All",
    filterSafe: "Looks Safe",
    filterMedium: "Be Careful",
    filterHigh: "Needs Attention",
    emptyHistoryTitle: "You have not checked any transactions yet",
    emptyHistoryDesc: "Whenever you check a transaction, it will be saved here so you can easily review it anytime.",
    btnPrevPage: "← Previous",
    btnNextPage: "Next →",

    // Help View
    helpTitle: "Help & Guidance",
    helpSubtitle: "Simple answers to common questions about keeping your payments safe.",
    faq1Q: "What is FraudShield AI?",
    faq1A: "FraudShield AI is a simple, easy-to-use tool that checks transaction details before you pay. It looks for common warning signs such as unusually high amounts, unfamiliar locations, or suspicious shop categories.",
    faq2Q: "How do I check a transaction?",
    faq2Step1: "Click on Check Transaction in the top menu or on Home.",
    faq2Step2: "Enter the amount of money and the name of the shop or business.",
    faq2Step3: "Click CHECK THIS TRANSACTION. Your result appears in seconds.",
    faq3Q: "What does 'Looks Safe' mean?",
    faq3A: "'Looks Safe' means that the details you entered match normal, everyday payment patterns. No red flags were spotted. You should still take standard care when entering your PIN.",
    faq4Q: "What does 'Be Careful' mean?",
    faq4A: "'Be Careful' means one or two details looked unusual — for example, the amount is notably higher than normal, or the purchase was made in a city you don't usually visit. Take a moment to verify the details before you pay.",
    faq5Q: "What does 'Needs Attention' mean?",
    faq5A: "'Needs Attention' means multiple warning signs were detected. The transaction might be an attempted scam or fraudulent request. Do not send any money until you have called your bank or payment provider to confirm.",
    faq6Q: "What should I do if a transaction looks suspicious?",
    faq6Point1: "Stop. Do not share your OTP, UPI PIN, or password with anyone.",
    faq6Point2: "Call the official telephone number printed on the back of your bank card.",
    faq6Point3: "If someone is rushing or threatening you to pay immediately, it is almost certainly a scam.",

    // Account View
    lblTotalChecks: "Transactions Checked",
    lblMemberSince: "Member Since",
    lblPreferredLang: "Language Preference",

    // Admin View
    adminTitle: "System Administration",
    adminSubtitle: "High-level platform activity and safety summary.",
    lblTotalUsers: "Registered Users",
    lblTotalTxns: "Total Checks",
    lblSafeChecks: "Safe Checks",
    lblWarningChecks: "Warning Signs",
    lblRecentSystemChecks: "Recent System Checks",
    colRef: "Reference",
    colUser: "User",
    colAmount: "Amount",
    colShop: "Shop / Business",
    colResult: "Result",

    // Auth Modal
    tabSignIn: "Sign In",
    tabCreateAccount: "Create Account",
    loginHeading: "Welcome Back",
    loginSubheading: "Log in to view your previous transaction checks.",
    lblEmail: "Email Address",
    hintEmail: "Enter the email you registered with.",
    lblPassword: "Password",
    demoAccountsTitle: "Quick One-Click Test Accounts:",
    noAccountText: "Don't have an account yet?",
    createOneNow: "Create one now",
    registerHeading: "Create Your Account",
    registerSubheading: "Free, fast, and gives you access to all your previous checks.",
    lblFullName: "Your Full Name",
    hintEmailRegister: "We will use this to sign you in.",
    hintPasswordRule: "Must be at least 6 characters long.",
    alreadyHaveAccountText: "Already have an account?",
    signInHere: "Sign in here",

    // Footer
    footerDesc: "Making payment safety understandable for everyone. Always verify payments before sending money.",
    footerNavTitle: "Quick Links",
    allRightsReserved: "All rights reserved.",
    footerNotice: "FraudShield AI is an educational and risk estimation application built with Spring Boot. It does not replace your bank's official authorization."
  },

  hi: {
    tagline: "धोखाधड़ी की जाँच • सुरक्षित रहें",
    navHome: "होम",
    navCheck: "लेन-देन जाँचें",
    navCheckShort: "जाँचें",
    navHistory: "पिछले चेक",
    navHistoryShort: "इतिहास",
    navHelp: "मदद",
    navAccount: "मेरा खाता",
    navAccountShort: "खाता",
    navAdmin: "एडमिन रिपोर्ट",
    btnSignIn: "लॉग इन करें",
    btnSignOut: "लॉग आउट",
    btnCreateAccount: "खाता बनाएँ",

    // Home View
    heroChip: "सरल, सुरक्षित और हर किसी के लिए आसान",
    homeTitle: "पैसे भेजने से पहले जाँचें कि भुगतान सुरक्षित है या नहीं",
    homeSubtitle: "किसी भुगतान, दुकान या ऑनलाइन ट्रांसफर को लेकर मन में शक है? आसान शब्दों में तुरंत नतीजा देखने के लिए कुछ बुनियादी जानकारी दर्ज करें।",
    btnCheckAction: "लेन-देन की जाँच करें",
    btnPreviousAction: "पिछले चेक देखें",
    howItWorksTitle: "यह कैसे काम करता है?",
    howItWorksSubtitle: "किसी भी लेन-देन की जाँच करना केवल 3 आसान चरणों में संभव है।",
    step1Title: "1. जानकारी भरें",
    step1Desc: "भुगतान की रकम और दुकान या व्यापार का नाम लिखें।",
    step2Title: "2. जाँचें दबाएँ",
    step2Desc: "हमारा सुरक्षा सिस्टम चेतावनी के संकेतों और असामान्य बातों की जाँच करेगा।",
    step3Title: "3. नतीजा देखें",
    step3Desc: "साफ़ और सीधा जवाब पाएँ: सुरक्षित लग रहा है, सावधान रहें, या ध्यान दें।",
    disclaimerTitle: "पैसे भेजने से पहले हमेशा पुष्टि करें:",
    disclaimerText: "FraudShield AI आपको चेतावनी के संकेत पहचानने में मदद करने के लिए एक सुरक्षा अनुमान देता है। यह आपके बैंक की सुरक्षा का विकल्प नहीं है।",

    // Check Form View
    backHome: "होम",
    checkTitle: "लेन-देन की जाँच करें",
    checkSubtitle: "नीचे दी गई जानकारी भरें। हम देखेंगे कि क्या कुछ असामान्य लग रहा है।",
    step1Tab: "1. बुनियादी जानकारी",
    step2Tab: "2. अतिरिक्त जानकारी (वैकल्पिक)",
    quickPresetsLabel: "त्वरित परीक्षण उदाहरण:",
    presetSafe: "सुरक्षित किराने का सामान ($45)",
    presetMedium: "असामान्य खरीदारी ($750)",
    presetHigh: "संदिग्ध ट्रांसफर ($4,850)",
    lblAmount: "भुगतान राशि",
    hintAmount: "वह रकम लिखें जो आप चुका रहे हैं या माँगी गई है।",
    lblShopName: "दुकान, व्यापार या व्यक्ति का नाम",
    hintShopName: "यह भुगतान किसे किया जा रहा है?",
    quickSelect: "जल्दी चुनें:",
    catGrocery: "किराना",
    catShopping: "खरीदारी",
    catElectronics: "इलेक्ट्रॉनिक्स",
    catBills: "बिल भुगतान",
    catTravel: "यात्रा",
    catCrypto: "क्रिप्टो",
    lblDateTime: "यह लेन-देन कब हुआ?",
    hintDateTime: "वर्तमान समय स्वतः चुना गया है। अगर पहले का लेन-देन है तो बदलें।",
    btnNextDetails: "आगे बढ़ें: अतिरिक्त जानकारी (वैकल्पिक) →",
    step2Note: "यह जानकारी सुरक्षा जाँच को और सटीक बनाती है। अगर आपको जानकारी नहीं पता, तो इसे ऐसे ही छोड़ सकते हैं।",
    lblPaymentMethod: "भुगतान किस माध्यम से किया जा रहा है?",
    optCard: "डेबिट या क्रेडिट कार्ड",
    optUPI: "यूपीआई / फोनपे / गूगल पे / पेटीएम",
    optNetBanking: "नेट बैंकिंग / बिल पे",
    optATM: "एटीएम से नकदी निकासी",
    lblCity: "शहर या स्थान",
    hintCity: "यह लेन-देन किस शहर से किया गया या माँगा गया?",
    lblUsualCity: "आपका सामान्य शहर या गृह नगर",
    hintUsualCity: "यह देखने के लिए कि क्या लेन-देन किसी अनजान शहर से हुआ है।",
    lblDevice: "किस डिवाइस का उपयोग किया गया?",
    optMyPhone: "मेरा अपना फोन (जाना-पहचाना फोन)",
    optMyComputer: "मेरा कंप्यूटर या लैपटॉप",
    optNewDevice: "नया या किसी अन्य का डिवाइस",
    lblNewDeviceCheckbox: "यह लेन-देन बिल्कुल नए या किसी अन्य व्यक्ति के डिवाइस से किया गया",
    btnBackStep: "← पहले चरण पर वापस जाएँ",
    btnCheckSubmit: "इस लेन-देन की जाँच करें",
    checkingProgress: "सुरक्षा जाँची जा रही है... कृपया प्रतीक्षा करें",

    // Result View
    checkAnother: "एक और लेन-देन जाँचें",
    lblReference: "चेक संदर्भ संख्या:",
    safetyResultLabel: "सुरक्षा परिणाम",
    safeTitle: "सुरक्षित लग रहा है",
    safeDesc: "दी गई जानकारी में कुछ भी असामान्य नहीं मिला। भुगतान की पुष्टि करने से पहले हमेशा सावधानी बरतें।",
    mediumTitle: "सावधान रहें",
    mediumDesc: "कुछ जानकारी असामान्य लग रही है। आगे बढ़ने से पहले विवरण की अच्छी तरह पुष्टि कर लें।",
    highTitle: "ध्यान देने की ज़रूरत है",
    highDesc: "इस लेन-देन में कई चेतावनी के संकेत मिले हैं। अपने बैंक से पुष्टि किए बिना आगे न बढ़ें।",
    safetyScoreTitle: "सुरक्षा स्कोर",
    tierSafe: "सुरक्षित लग रहा है",
    tierMedium: "सावधान रहें",
    tierHigh: "ध्यान देने की ज़रूरत है",
    scoreExplanation: "कम स्कोर का मतलब है कि कम चेतावनी के संकेत मिले हैं। अधिक स्कोर का मतलब है कि अधिक सावधान रहने की आवश्यकता है।",
    txnSummaryTitle: "जाँची गई लेन-देन की जानकारी",
    reasonsTitle: "इस नतीजे के मुख्य कारण",
    nextStepsTitle: "अब मुझे आगे क्या करना चाहिए?",
    transparencyNotice: "सूचना: यह सुरक्षा स्कोर सामान्य वित्तीय सुरक्षा नियमों पर आधारित है। यह केवल एक सलाहकारी अनुमान है।",
    btnCheckAnother: "एक और लेन-देन जाँचें",
    btnSeePrevious: "पिछले चेक देखें",
    btnPrint: "प्रिंट या सेव करें",
    btnBackHome: "होम पर लौटें",

    // Previous Checks View
    historyTitle: "पिछले चेक",
    historySubtitle: "अपने पिछले भुगतान सुरक्षा चेकों की समीक्षा करें।",
    btnNewCheck: "नया चेक",
    searchPlaceholder: "संदर्भ संख्या या दुकान के नाम से खोजें...",
    filterAll: "सभी",
    filterSafe: "सुरक्षित",
    filterMedium: "सावधान",
    filterHigh: "ध्यान दें",
    emptyHistoryTitle: "आपने अभी तक किसी लेन-देन की जाँच नहीं की है",
    emptyHistoryDesc: "जब भी आप किसी लेन-देन की जाँच करेंगे, वह यहाँ सुरक्षित रहेगी ताकि आप कभी भी देख सकें।",
    btnPrevPage: "← पिछला",
    btnNextPage: "अगला →",

    // Help View
    helpTitle: "मदद और मार्गदर्शन",
    helpSubtitle: "अपने भुगतानों को सुरक्षित रखने से जुड़े सामान्य प्रश्नों के सरल उत्तर।",
    faq1Q: "FraudShield AI क्या है?",
    faq1A: "FraudShield AI एक बेहद सरल टूल है जो पैसे भेजने से पहले लेन-देन की जाँच करता है। यह असामान्य रकम, अनजान जगह या संदिग्ध दुकान श्रेणियों जैसे चेतावनी के संकेतों को पहचानता है।",
    faq2Q: "लेन-देन की जाँच कैसे करें?",
    faq2Step1: "मेनू में 'लेन-देन जाँचें' पर क्लिक करें।",
    faq2Step2: "रकम और दुकान या व्यक्ति का नाम लिखें।",
    faq2Step3: "'इस लेन-देन की जाँच करें' बटन दबाएँ। नतीजा कुछ ही सेकंडों में दिखेगा।",
    faq3Q: "'सुरक्षित लग रहा है' का क्या अर्थ है?",
    faq3A: "इसका मतलब है कि आपके द्वारा दर्ज की गई जानकारी सामान्य रोज़मर्रा के भुगतानों से मेल खाती है। कोई लाल झंडा नहीं दिखा। फिर भी पिन डालते समय सामान्य सावधानी रखें।",
    faq4Q: "'सावधान रहें' का क्या अर्थ है?",
    faq4A: "इसका मतलब है कि एक-दो बातें असामान्य लगीं—जैसे रकम सामान्य से अधिक है या लेन-देन किसी अनजान शहर से हुआ है। पैसे भेजने से पहले विवरण ज़रूर जाँच लें।",
    faq5Q: "'ध्यान देने की ज़रूरत है' का क्या अर्थ है?",
    faq5A: "इसका मतलब है कि लेन-देन में कई चेतावनी के संकेत मिले हैं। यह धोखाधड़ी की कोशिश हो सकती है। अपने बैंक से बात किए बिना पैसे बिल्कुल न भेजें।",
    faq6Q: "यदि कोई लेन-देन संदिग्ध लगे तो मुझे क्या करना चाहिए?",
    faq6Point1: "रुकें। अपना ओटीपी, यूपीआई पिन या पासवर्ड किसी के साथ भी साझा न करें।",
    faq6Point2: "अपने बैंक कार्ड के पीछे दिए गए आधिकारिक फोन नंबर पर तुरंत कॉल करें।",
    faq6Point3: "अगर कोई जल्दबाजी करने या डराने की कोशिश कर रहा है, तो यह निश्चित रूप से धोखाधड़ी हो सकती है।",

    // Account View
    lblTotalChecks: "जाँचे गए लेन-देन",
    lblMemberSince: "सदस्यता की तारीख",
    lblPreferredLang: "भाषा प्राथमिकता",

    // Admin View
    adminTitle: "सिस्टम प्रशासन",
    adminSubtitle: "प्लेटफ़ॉर्म गतिविधि और सुरक्षा का उच्च-स्तरीय सारांश।",
    lblTotalUsers: "पंजीकृत उपयोगकर्ता",
    lblTotalTxns: "कुल चेक",
    lblSafeChecks: "सुरक्षित चेक",
    lblWarningChecks: "चेतावनी वाले चेक",
    lblRecentSystemChecks: "हाल के सिस्टम चेक",
    colRef: "संदर्भ संख्या",
    colUser: "उपयोगकर्ता",
    colAmount: "रकम",
    colShop: "दुकान / व्यापार",
    colResult: "परिणाम",

    // Auth Modal
    tabSignIn: "लॉग इन",
    tabCreateAccount: "खाता बनाएँ",
    loginHeading: "वापसी पर स्वागत है",
    loginSubheading: "अपने पिछले लेन-देन चेक देखने के लिए लॉग इन करें।",
    lblEmail: "ईमेल पता",
    hintEmail: "अपना पंजीकृत ईमेल पता लिखें।",
    lblPassword: "पासवर्ड",
    demoAccountsTitle: "त्वरित परीक्षण खाते (1-क्लिक):",
    noAccountText: "क्या आपके पास अभी तक खाता नहीं है?",
    createOneNow: "नया खाता बनाएँ",
    registerHeading: "अपना खाता बनाएँ",
    registerSubheading: "निःशुल्क, तेज़ और आपके सभी पिछले चेकों को सुरक्षित रखता है।",
    lblFullName: "आपका पूरा नाम",
    hintEmailRegister: "लॉग इन करने के लिए इस ईमेल का उपयोग होगा।",
    hintPasswordRule: "कम से कम 6 अक्षरों का होना चाहिए।",
    alreadyHaveAccountText: "पहले से खाता है?",
    signInHere: "यहाँ लॉग इन करें",

    // Footer
    footerDesc: "भुगतान सुरक्षा को हर किसी के लिए आसान बनाना। पैसे भेजने से पहले हमेशा पुष्टि करें।",
    footerNavTitle: "त्वरित लिंक",
    allRightsReserved: "सर्वाधिकार सुरक्षित।",
    footerNotice: "FraudShield AI एक शैक्षणिक और सुरक्षा अनुमान अनुप्रयोग है। यह आपके बैंक के आधिकारिक प्राधिकरण का स्थान नहीं लेता है।"
  }
};

// =============================================================================
// MAIN APPLICATION OBJECT
// =============================================================================
const App = {
  state: {
    token: localStorage.getItem('fs_token') || null,
    user: JSON.parse(localStorage.getItem('fs_user') || 'null'),
    lang: localStorage.getItem('fs_lang') || 'en',
    currentView: 'home',
    currentStep: 1,
    lastAnalysis: null,
    lastTxn: null,
    historyPage: 0,
    historyFilter: 'ALL',
    historySearch: '',
    searchDebounceTimer: null
  },

  init() {
    this.applyLanguage(this.state.lang);
    this.bindEvents();
    this.checkAuth();
    this.handleHashChange();
    window.addEventListener('hashchange', () => this.handleHashChange());
    this.initDefaultDateTime();
  },

  // ---------------------------------------------------------------------------
  // LANGUAGE & TRANSLATION ENGINE
  // ---------------------------------------------------------------------------
  setLanguage(lang) {
    if (lang !== 'en' && lang !== 'hi') lang = 'en';
    this.state.lang = lang;
    localStorage.setItem('fs_lang', lang);
    this.applyLanguage(lang);
  },

  applyLanguage(lang) {
    const dict = I18N[lang] || I18N.en;

    // Update active state of language buttons
    const btnEn = document.getElementById('btn-lang-en');
    const btnHi = document.getElementById('btn-lang-hi');
    if (btnEn && btnHi) {
      if (lang === 'en') {
        btnEn.classList.add('active');
        btnEn.setAttribute('aria-pressed', 'true');
        btnHi.classList.remove('active');
        btnHi.setAttribute('aria-pressed', 'false');
      } else {
        btnHi.classList.add('active');
        btnHi.setAttribute('aria-pressed', 'true');
        btnEn.classList.remove('active');
        btnEn.setAttribute('aria-pressed', 'false');
      }
    }

    // Translate all elements with data-i18n
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) {
        el.innerText = dict[key];
      }
    });

    // Translate placeholders
    document.querySelectorAll('[data-i18n-ph]').forEach(el => {
      const key = el.getAttribute('data-i18n-ph');
      if (dict[key]) {
        el.setAttribute('placeholder', dict[key]);
      }
    });

    // If result page is active, re-render result text in target language
    if (this.state.lastAnalysis && this.state.currentView === 'result') {
      this.renderAnalysisResult(this.state.lastAnalysis, this.state.lastTxn);
    }
  },

  t(key) {
    const dict = I18N[this.state.lang] || I18N.en;
    return dict[key] || (I18N.en[key] || key);
  },

  // ---------------------------------------------------------------------------
  // EVENT BINDINGS
  // ---------------------------------------------------------------------------
  bindEvents() {
    // Form submission for transaction check
    const checkForm = document.getElementById('check-transaction-form');
    if (checkForm) {
      checkForm.addEventListener('submit', (e) => this.handleTransactionSubmit(e));
    }

    // Login Form
    const loginForm = document.getElementById('form-login');
    if (loginForm) {
      loginForm.addEventListener('submit', (e) => this.handleLogin(e));
    }

    // Register Form
    const regForm = document.getElementById('form-register');
    if (regForm) {
      regForm.addEventListener('submit', (e) => this.handleRegister(e));
    }

    // Close modals on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.closeAuthModal();
        this.closeDetailModal();
      }
    });
  },

  initDefaultDateTime() {
    const dtInput = document.getElementById('inp-datetime');
    if (dtInput && !dtInput.value) {
      const now = new Date();
      now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
      dtInput.value = now.toISOString().slice(0, 16);
    }
  },

  // ---------------------------------------------------------------------------
  // ROUTING & VIEW NAVIGATION
  // ---------------------------------------------------------------------------
  handleHashChange() {
    const hash = window.location.hash.replace('#', '') || 'home';
    this.navigate(hash, false);
  },

  navigate(viewName, updateHash = true) {
    const validViews = ['home', 'check', 'result', 'history', 'help', 'account', 'admin'];
    const targetView = validViews.includes(viewName) ? viewName : 'home';

    // Auth guard for history and account
    if (['history', 'account'].includes(targetView) && !this.state.token) {
      this.showToast(this.t('loginSubheading'), 'info');
      this.openAuthModal('login');
      return;
    }

    // Admin guard
    if (targetView === 'admin') {
      if (!this.state.token) {
        this.openAuthModal('login');
        return;
      }
      if (this.state.user?.role !== 'ROLE_ADMIN') {
        this.showToast('Access denied: Administrator privileges required.', 'error');
        this.navigate('home');
        return;
      }
    }

    this.state.currentView = targetView;

    // Hide all view sections
    document.querySelectorAll('.app-view').forEach(view => {
      view.style.display = 'none';
    });

    // Show target view
    const viewEl = document.getElementById(`view-${targetView}`);
    if (viewEl) {
      viewEl.style.display = 'block';
    }

    // Update Desktop Nav Active State
    document.querySelectorAll('.nav-links .nav-item').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-view') === targetView);
    });

    // Update Mobile Nav Active State
    document.querySelectorAll('.mobile-bottom-nav .mobile-nav-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-view') === targetView);
    });

    // Hash sync
    if (updateHash && window.location.hash !== `#${targetView}`) {
      window.location.hash = `#${targetView}`;
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });

    // View specific hooks
    if (targetView === 'history') {
      this.loadHistory();
    } else if (targetView === 'account') {
      this.loadProfile();
    } else if (targetView === 'admin') {
      this.loadAdminData();
    } else if (targetView === 'check') {
      this.goToStep(1);
    }
  },

  // ---------------------------------------------------------------------------
  // STEP-BY-STEP FORM NAVIGATION
  // ---------------------------------------------------------------------------
  goToStep(stepNumber) {
    const errAmount = document.getElementById('err-amount');
    const errMerchant = document.getElementById('err-merchant');
    if (errAmount) errAmount.style.display = 'none';
    if (errMerchant) errMerchant.style.display = 'none';

    if (stepNumber === 2) {
      // Validate Step 1 first
      const amountVal = parseFloat(document.getElementById('inp-amount')?.value || '0');
      const merchantVal = document.getElementById('inp-merchant')?.value.trim();

      let hasError = false;
      if (!amountVal || amountVal <= 0) {
        if (errAmount) {
          errAmount.innerText = this.state.lang === 'hi' 
            ? 'कृपया एक मान्य राशि लिखें (शून्य से अधिक)' 
            : 'Please enter a valid amount greater than zero';
          errAmount.style.display = 'block';
        }
        hasError = true;
      }

      if (!merchantVal) {
        if (errMerchant) {
          errMerchant.innerText = this.state.lang === 'hi'
            ? 'कृपया दुकान, व्यापार या व्यक्ति का नाम लिखें'
            : 'Please enter the shop or business name';
          errMerchant.style.display = 'block';
        }
        hasError = true;
      }

      if (hasError) return;
    }

    this.state.currentStep = stepNumber;

    const step1Panel = document.getElementById('step-1-content');
    const step2Panel = document.getElementById('step-2-content');
    const tab1 = document.getElementById('tab-step-1');
    const tab2 = document.getElementById('tab-step-2');

    if (stepNumber === 1) {
      if (step1Panel) step1Panel.style.display = 'block';
      if (step2Panel) step2Panel.style.display = 'none';
      if (tab1) tab1.classList.add('active');
      if (tab2) tab2.classList.remove('active');
    } else {
      if (step1Panel) step1Panel.style.display = 'none';
      if (step2Panel) step2Panel.style.display = 'block';
      if (tab1) tab1.classList.remove('active');
      if (tab2) tab2.classList.add('active');
    }
  },

  setShopCategory(categoryCode, friendlyName) {
    const merchantInput = document.getElementById('inp-merchant');
    const catInput = document.getElementById('inp-merchant-category');
    if (catInput) catInput.value = categoryCode;
    if (merchantInput && !merchantInput.value.trim()) {
      merchantInput.value = friendlyName;
    }
  },

  loadPreset(presetType) {
    this.goToStep(1);
    const inpAmount = document.getElementById('inp-amount');
    const inpMerchant = document.getElementById('inp-merchant');
    const inpCategory = document.getElementById('inp-merchant-category');
    const inpPayMethod = document.getElementById('inp-payment-method');
    const inpLocation = document.getElementById('inp-location');
    const inpUsualLocation = document.getElementById('inp-usual-location');
    const inpDevice = document.getElementById('inp-device');
    const chkNewDevice = document.getElementById('chk-new-device');

    if (presetType === 'safe') {
      if (inpAmount) inpAmount.value = '45.00';
      if (inpMerchant) inpMerchant.value = 'Local Grocery Supermarket';
      if (inpCategory) inpCategory.value = 'RETAIL';
      if (inpPayMethod) inpPayMethod.value = 'PURCHASE';
      if (inpLocation) inpLocation.value = 'San Francisco, USA';
      if (inpUsualLocation) inpUsualLocation.value = 'San Francisco, USA';
      if (inpDevice) inpDevice.value = 'My Phone';
      if (chkNewDevice) chkNewDevice.checked = false;
      this.showToast('Loaded Safe Grocery Scenario ($45.00)', 'info');
    } else if (presetType === 'medium') {
      if (inpAmount) inpAmount.value = '750.00';
      if (inpMerchant) inpMerchant.value = 'Best Electronics Store';
      if (inpCategory) inpCategory.value = 'ELECTRONICS';
      if (inpPayMethod) inpPayMethod.value = 'PURCHASE';
      if (inpLocation) inpLocation.value = 'Seattle, USA';
      if (inpUsualLocation) inpUsualLocation.value = 'San Francisco, USA';
      if (inpDevice) inpDevice.value = 'My Phone';
      if (chkNewDevice) chkNewDevice.checked = false;
      this.showToast('Loaded Moderate Risk Scenario ($750.00)', 'info');
    } else if (presetType === 'high') {
      if (inpAmount) inpAmount.value = '4850.00';
      if (inpMerchant) inpMerchant.value = 'Global Crypto Transfer Service';
      if (inpCategory) inpCategory.value = 'CRYPTO_EXCHANGE';
      if (inpPayMethod) inpPayMethod.value = 'ONLINE_TRANSFER';
      if (inpLocation) inpLocation.value = 'London, UK';
      if (inpUsualLocation) inpUsualLocation.value = 'San Francisco, USA';
      if (inpDevice) inpDevice.value = 'Unknown Device';
      if (chkNewDevice) chkNewDevice.checked = true;
      this.showToast('Loaded High Warning Scenario ($4,850.00)', 'info');
    }
  },

  // ---------------------------------------------------------------------------
  // TRANSACTION SUBMISSION (With Auto-Auth & Double-Click Guard)
  // ---------------------------------------------------------------------------
  async handleTransactionSubmit(e) {
    e.preventDefault();

    const submitBtn = document.getElementById('btn-submit-txn');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = `
        <span style="display:inline-block; animation: spin 1s linear infinite; margin-right: 0.5rem;">⏳</span>
        ${this.t('checkingProgress')}
      `;
    }

    // Step 1 Validation
    const amountVal = parseFloat(document.getElementById('inp-amount')?.value || '0');
    const merchantVal = document.getElementById('inp-merchant')?.value.trim();

    if (!amountVal || amountVal <= 0 || !merchantVal) {
      this.goToStep(1);
      this.showToast('Please enter an amount and shop name.', 'error');
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = this.t('btnCheckSubmit');
      }
      return;
    }

    // Auto-login fallback if user is guest: seamlessly logs in as John Doe so beginners are never blocked
    if (!this.state.token) {
      try {
        const autoLoginRes = await fetch(`${API_BASE}/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: 'john.doe@example.com', password: 'User@123' })
        });
        if (autoLoginRes.ok) {
          const authData = await autoLoginRes.json();
          this.setSession(authData);
        }
      } catch (err) {
        console.warn('Auto guest login skipped:', err);
      }
    }

    const payload = {
      amount: amountVal,
      currency: document.getElementById('inp-currency')?.value || 'USD',
      merchantCategory: document.getElementById('inp-merchant-category')?.value || 'RETAIL',
      transactionType: document.getElementById('inp-payment-method')?.value || 'PURCHASE',
      location: document.getElementById('inp-location')?.value || 'San Francisco, USA',
      usualLocation: document.getElementById('inp-usual-location')?.value || 'San Francisco, USA',
      deviceType: document.getElementById('inp-device')?.value || 'My Phone',
      newDevice: document.getElementById('chk-new-device')?.checked || false,
      failedAttempts: 0,
      transactionFrequency: 1
    };

    try {
      // 1. Create Transaction
      const txnRes = await fetch(`${API_BASE}/transactions`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify(payload)
      });

      if (!txnRes.ok) {
        const errJson = await txnRes.json();
        throw new Error(errJson.message || 'Could not record transaction. Please try again.');
      }

      const txnData = await txnRes.json();
      this.state.lastTxn = txnData;

      // 2. Perform Fraud Check
      const analyzeRes = await fetch(`${API_BASE}/fraud/analyze/${txnData.id}`, {
        method: 'POST',
        headers: this.getAuthHeaders()
      });

      if (!analyzeRes.ok) {
        const errJson = await analyzeRes.json();
        throw new Error(errJson.message || 'Safety check failed. Please try again.');
      }

      const analysisData = await analyzeRes.json();
      this.state.lastAnalysis = analysisData;

      // 3. Render and display Result Page
      this.renderAnalysisResult(analysisData, txnData);
      this.navigate('result');
      this.showToast(this.t('checkSubtitle'), 'success');

    } catch (err) {
      this.showToast(err.message, 'error');
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = `
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            <path d="M9 12l2 2 4-4"/>
          </svg>
          <span>${this.t('btnCheckSubmit')}</span>
        `;
      }
    }
  },

  // ---------------------------------------------------------------------------
  // RESULT PAGE RENDERING (Plain Language • 3 Clear Categories)
  // ---------------------------------------------------------------------------
  renderAnalysisResult(analysis, txn) {
    if (!analysis) return;

    const banner = document.getElementById('res-banner-card');
    const bannerIcon = document.getElementById('res-banner-icon');
    const titleEl = document.getElementById('res-category-title');
    const descEl = document.getElementById('res-category-desc');
    const refEl = document.getElementById('res-txn-ref');
    const scoreVal = document.getElementById('res-score-value');
    const scoreBar = document.getElementById('res-score-bar');
    const reasonsList = document.getElementById('res-reasons-list');
    const nextStepsList = document.getElementById('res-next-steps-list');

    // Reference ID
    if (refEl) refEl.innerText = analysis.transactionReference || 'TXN-0000';

    // Transaction Details Summary
    const detAmount = document.getElementById('res-det-amount');
    const detMerchant = document.getElementById('res-det-merchant');
    const detLocation = document.getElementById('res-det-location');
    const detDevice = document.getElementById('res-det-device');
    const detDate = document.getElementById('res-det-date');

    const amountNum = (txn?.amount || analysis?.transaction?.amount || 0);
    const curr = (txn?.currency || '$');
    if (detAmount) detAmount.innerText = `${curr === 'USD' ? '$' : curr}${amountNum.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
    if (detMerchant) detMerchant.innerText = txn?.merchantCategory || document.getElementById('inp-merchant')?.value || 'Shop / Business';
    if (detLocation) detLocation.innerText = txn?.location || 'San Francisco, USA';
    if (detDevice) detDevice.innerText = txn?.deviceType || 'My Phone';
    if (detDate) detDate.innerText = new Date(txn?.createdAt || Date.now()).toLocaleString();

    // Map Risk Level to the 3 Clear Categories
    const level = (analysis.riskLevel || 'LOW').toUpperCase();
    const score = analysis.riskScore || 0;

    if (scoreVal) scoreVal.innerText = `${score} / 100`;
    if (scoreBar) {
      scoreBar.style.width = `${Math.min(100, Math.max(8, score))}%`;
      if (level === 'LOW') {
        scoreBar.style.backgroundColor = 'var(--safe-green)';
      } else if (level === 'MEDIUM') {
        scoreBar.style.backgroundColor = 'var(--warning-amber)';
      } else {
        scoreBar.style.backgroundColor = 'var(--danger-red)';
      }
    }

    if (banner) {
      banner.className = 'result-banner';
      if (level === 'LOW') {
        banner.classList.add('banner-safe');
        if (titleEl) titleEl.innerText = this.t('safeTitle');
        if (descEl) descEl.innerText = this.t('safeDesc');
        if (bannerIcon) {
          bannerIcon.innerHTML = `
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              <polyline points="9 12 11 14 15 10"/>
            </svg>
          `;
        }
      } else if (level === 'MEDIUM') {
        banner.classList.add('banner-medium');
        if (titleEl) titleEl.innerText = this.t('mediumTitle');
        if (descEl) descEl.innerText = this.t('mediumDesc');
        if (bannerIcon) {
          bannerIcon.innerHTML = `
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round">
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
              <line x1="12" y1="9" x2="12" y2="13"/>
              <line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
          `;
        }
      } else {
        banner.classList.add('banner-high');
        if (titleEl) titleEl.innerText = this.t('highTitle');
        if (descEl) descEl.innerText = this.t('highDesc');
        if (bannerIcon) {
          bannerIcon.innerHTML = `
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"/>
              <line x1="15" y1="9" x2="9" y2="15"/>
              <line x1="9" y1="9" x2="15" y2="15"/>
            </svg>
          `;
        }
      }
    }

    // Top 3 Reasons
    if (reasonsList) {
      reasonsList.innerHTML = '';
      const factors = analysis.riskFactors || [];

      if (factors.length === 0 || level === 'LOW') {
        const item = document.createElement('li');
        item.className = 'reason-item safe-border';
        item.innerHTML = `
          <span class="reason-bullet" style="color:var(--safe-green);" aria-hidden="true">✓</span>
          <span>${this.state.lang === 'hi' 
            ? 'भुगतान की रकम, दुकान की श्रेणी और डिवाइस सभी सामान्य रोज़मर्रा के पैटर्न से मेल खाते हैं।' 
            : 'Payment amount, shop category, and device all match typical everyday purchase patterns.'}</span>
        `;
        reasonsList.appendChild(item);

        const item2 = document.createElement('li');
        item2.className = 'reason-item safe-border';
        item2.innerHTML = `
          <span class="reason-bullet" style="color:var(--safe-green);" aria-hidden="true">✓</span>
          <span>${this.state.lang === 'hi'
            ? 'कोई पूर्व असफल लॉगिन या संदिग्ध प्रयास दर्ज नहीं किए गए।'
            : 'No prior unsuccessful tries or suspicious velocity spikes detected.'}</span>
        `;
        reasonsList.appendChild(item2);
      } else {
        factors.slice(0, 3).forEach(rf => {
          const item = document.createElement('li');
          const isHigh = rf.severity === 'HIGH';
          item.className = `reason-item ${isHigh ? 'danger-border' : 'warning-border'}`;
          item.innerHTML = `
            <span class="reason-bullet" style="color:${isHigh ? 'var(--danger-red)' : 'var(--warning-amber)'};" aria-hidden="true">${isHigh ? '✕' : '⚠'}</span>
            <div>
              <strong>${this.simplifyFactorTitle(rf.factorCode)}</strong>
              <div style="font-size: 0.92rem; color: var(--text-secondary); margin-top: 0.15rem;">${rf.description}</div>
            </div>
          `;
          reasonsList.appendChild(item);
        });
      }
    }

    // What Should I Do Next? (Actionable Concrete Guidance)
    if (nextStepsList) {
      nextStepsList.innerHTML = '';
      let steps = [];

      if (level === 'LOW') {
        if (this.state.lang === 'hi') {
          steps = [
            "पुष्टि करें कि प्राप्तकर्ता या दुकान का नाम आपकी स्क्रीन पर सही दिख रहा है।",
            "अपना यूपीआई पिन या कार्ड विवरण दर्ज करने से पहले अंतिम राशि की दोबारा जाँच करें।",
            "लेन-देन पूरा होने के बाद प्राप्त एसएमएस या रसीद को सुरक्षित रखें।"
          ];
        } else {
          steps = [
            "Confirm that the recipient or shop name shown on your payment screen is correct.",
            "Double-check the final amount before entering your PIN or payment password.",
            "Keep the receipt or confirmation message for your records."
          ];
        }
      } else if (level === 'MEDIUM') {
        if (this.state.lang === 'hi') {
          steps = [
            "सुनिश्चित करें कि आप बैंक या भुगतान ऐप की आधिकारिक और असली वेबसाइट पर हैं।",
            "अपना ओटीपी, पिन या पासवर्ड कभी भी किसी कॉल, संदेश या व्यक्ति के साथ साझा न करें।",
            "यदि किसी ने आपसे जल्दबाजी में पैसे भेजने को कहा है, तो रुकें और उनसे सीधे फोन करके पूछें।"
          ];
        } else {
          steps = [
            "Ensure you are on the authentic official website or payment app.",
            "Never share your OTP, UPI PIN, or bank passwords with anyone over call or chat.",
            "If someone asked you to pay urgently, pause and verify with them in person or by phone."
          ];
        }
      } else {
        if (this.state.lang === 'hi') {
          steps = [
            "रुकें! अभी अपना पिन दर्ज न करें और न ही कोई पैसा भेजें।",
            "अपने बैंक कार्ड के पीछे दिए गए आधिकारिक फोन नंबर पर तुरंत संपर्क करें।",
            "यदि यह लेन-देन आपने नहीं किया है, तो अपने बैंक ऐप में कार्ड या यूपीआई तुरंत बंद (लॉक) करें।"
          ];
        } else {
          steps = [
            "Stop! Do not enter your PIN or send any money right now.",
            "Call the official phone number printed on the back of your bank card immediately.",
            "If you did not initiate this payment, lock your card or UPI in your banking app right away."
          ];
        }
      }

      steps.forEach((text, idx) => {
        const row = document.createElement('div');
        row.className = 'next-step-item';
        row.innerHTML = `
          <span class="next-step-num" aria-hidden="true">${idx + 1}</span>
          <span>${text}</span>
        `;
        nextStepsList.appendChild(row);
      });
    }
  },

  simplifyFactorTitle(code) {
    const titles = {
      EXTREME_AMOUNT: this.state.lang === 'hi' ? 'अत्यधिक बड़ी रकम' : 'High Payment Amount',
      AMOUNT_DEVIATION: this.state.lang === 'hi' ? 'सामान्य से अधिक रकम' : 'Higher Than Normal Spending',
      MODERATE_AMOUNT_SPIKE: this.state.lang === 'hi' ? 'रकम में बढ़ोतरी' : 'Elevated Amount',
      UNKNOWN_DEVICE: this.state.lang === 'hi' ? 'अनजान या नया डिवाइस' : 'New or Unrecognized Device',
      LOCATION_ANOMALY: this.state.lang === 'hi' ? 'असामान्य शहर या स्थान' : 'Unusual City or Location',
      MULTIPLE_FAILED_ATTEMPTS: this.state.lang === 'hi' ? 'कई बार गलत पासवर्ड का प्रयास' : 'Multiple Failed Login Attempts',
      RAPID_VELOCITY_BURST: this.state.lang === 'hi' ? 'कम समय में बहुत सारे लेन-देन' : 'Too Many Transactions in a Short Time',
      HIGH_RISK_MERCHANT: this.state.lang === 'hi' ? 'उच्च जोखिम वाली दुकान श्रेणी' : 'High-Risk Shop Category',
      NEW_ACCOUNT_HIGH_VALUE: this.state.lang === 'hi' ? 'नए खाते से बड़ी रकम' : 'High Value on New Account'
    };
    return titles[code] || (this.state.lang === 'hi' ? 'असामान्य संकेत' : 'Unusual Signal');
  },

  // ---------------------------------------------------------------------------
  // PREVIOUS CHECKS (History View with Search & Filter)
  // ---------------------------------------------------------------------------
  debounceSearchHistory() {
    clearTimeout(this.state.searchDebounceTimer);
    this.state.searchDebounceTimer = setTimeout(() => {
      this.state.historySearch = document.getElementById('history-search')?.value.trim() || '';
      this.state.historyPage = 0;
      this.loadHistory();
    }, 300);
  },

  setHistoryFilter(filter) {
    this.state.historyFilter = filter;
    this.state.historyPage = 0;

    document.querySelectorAll('.filter-pills .filter-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-filter') === filter);
    });

    this.loadHistory();
  },

  changeHistoryPage(delta) {
    this.state.historyPage = Math.max(0, this.state.historyPage + delta);
    this.loadHistory();
  },

  async loadHistory() {
    const container = document.getElementById('history-list-container');
    const emptyState = document.getElementById('history-empty');
    const paginationBar = document.getElementById('history-pagination');
    const pageInfo = document.getElementById('history-page-info');

    if (!this.state.token) {
      if (emptyState) emptyState.style.display = 'block';
      if (container) container.innerHTML = '';
      return;
    }

    try {
      let url = `${API_BASE}/transactions?page=${this.state.historyPage}&size=8`;
      if (this.state.historySearch) {
        url += `&search=${encodeURIComponent(this.state.historySearch)}`;
      }
      if (this.state.historyFilter && this.state.historyFilter !== 'ALL') {
        url += `&status=${encodeURIComponent(this.state.historyFilter)}`;
      }

      const res = await fetch(url, { headers: this.getAuthHeaders() });
      if (!res.ok) throw new Error('Failed to load transaction history');

      const data = await res.json();
      const items = data.content || [];

      if (items.length === 0) {
        if (container) container.innerHTML = '';
        if (emptyState) emptyState.style.display = 'block';
        if (paginationBar) paginationBar.style.display = 'none';
        return;
      }

      if (emptyState) emptyState.style.display = 'none';
      if (container) container.innerHTML = '';

      items.forEach(txn => {
        const card = document.createElement('div');
        card.className = 'history-card';
        card.setAttribute('role', 'button');
        card.setAttribute('tabindex', '0');
        card.setAttribute('aria-label', `View details for check ${txn.transactionReference}`);

        const riskLevel = txn.riskLevel || 'LOW';
        let indClass = 'status-ind-safe';
        let badgeClass = 'badge-safe';
        let statusText = this.t('safeTitle');
        let iconSymbol = '✓';

        if (riskLevel === 'HIGH' || txn.status === 'BLOCKED') {
          indClass = 'status-ind-high';
          badgeClass = 'badge-high';
          statusText = this.t('highTitle');
          iconSymbol = '✕';
        } else if (riskLevel === 'MEDIUM' || txn.status === 'FLAGGED_FOR_REVIEW') {
          indClass = 'status-ind-medium';
          badgeClass = 'badge-medium';
          statusText = this.t('mediumTitle');
          iconSymbol = '⚠';
        }

        const dateStr = new Date(txn.createdAt).toLocaleDateString(undefined, {
          month: 'short', day: 'numeric', year: 'numeric'
        });

        const currencySymbol = (txn.currency === 'USD' ? '$' : (txn.currency || '$'));

        card.innerHTML = `
          <div class="history-card-left">
            <div class="history-status-indicator ${indClass}" aria-hidden="true">${iconSymbol}</div>
            <div>
              <div class="history-shop-title">${txn.merchantCategory || 'Purchase'}</div>
              <div class="history-meta">
                <span class="mono">${txn.transactionReference}</span> • ${dateStr} • ${txn.location || 'Local'}
              </div>
            </div>
          </div>
          <div class="history-card-right">
            <div class="history-amount mono">${currencySymbol}${txn.amount?.toFixed(2)}</div>
            <span class="badge ${badgeClass} badge-pill">${statusText}</span>
          </div>
        `;

        card.addEventListener('click', () => this.inspectTransaction(txn.id));
        card.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.inspectTransaction(txn.id);
          }
        });

        container.appendChild(card);
      });

      // Pagination
      if (paginationBar) {
        if (data.totalPages > 1) {
          paginationBar.style.display = 'flex';
          if (pageInfo) pageInfo.innerText = `Page ${data.number + 1} of ${data.totalPages}`;
          const btnPrev = document.getElementById('btn-page-prev');
          const btnNext = document.getElementById('btn-page-next');
          if (btnPrev) btnPrev.disabled = data.first;
          if (btnNext) btnNext.disabled = data.last;
        } else {
          paginationBar.style.display = 'none';
        }
      }

    } catch (err) {
      console.error(err);
      this.showToast('Could not load previous checks.', 'error');
    }
  },

  async inspectTransaction(id) {
    try {
      const res = await fetch(`${API_BASE}/transactions/${id}`, {
        headers: this.getAuthHeaders()
      });
      if (!res.ok) throw new Error('Transaction record not found');

      const txn = await res.json();
      if (txn.fraudAnalysis) {
        this.state.lastTxn = txn;
        this.state.lastAnalysis = txn.fraudAnalysis;
        this.renderAnalysisResult(txn.fraudAnalysis, txn);
        this.navigate('result');
      } else {
        // Run analysis on demand if needed
        const aRes = await fetch(`${API_BASE}/fraud/analyze/${id}`, {
          method: 'POST',
          headers: this.getAuthHeaders()
        });
        if (aRes.ok) {
          const analysis = await aRes.json();
          this.state.lastTxn = txn;
          this.state.lastAnalysis = analysis;
          this.renderAnalysisResult(analysis, txn);
          this.navigate('result');
        }
      }
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // ---------------------------------------------------------------------------
  // AUTHENTICATION & SESSION
  // ---------------------------------------------------------------------------
  async checkAuth() {
    if (!this.state.token) {
      this.updateAuthUI(false);
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/auth/me`, {
        headers: this.getAuthHeaders()
      });

      if (res.ok) {
        const user = await res.json();
        this.state.user = user;
        localStorage.setItem('fs_user', JSON.stringify(user));
        this.updateAuthUI(true);
      } else {
        this.logout(false);
      }
    } catch (e) {
      console.warn('Auth token verification error:', e);
      this.updateAuthUI(false);
    }
  },

  getAuthHeaders() {
    const headers = { 'Content-Type': 'application/json' };
    if (this.state.token) {
      headers['Authorization'] = `Bearer ${this.state.token}`;
    }
    return headers;
  },

  updateAuthUI(isLoggedIn) {
    const container = document.getElementById('nav-auth-container');
    const adminLink = document.getElementById('nav-admin-link');

    if (adminLink) {
      adminLink.style.display = (isLoggedIn && this.state.user?.role === 'ROLE_ADMIN') ? 'inline-flex' : 'none';
    }

    if (!container) return;

    if (isLoggedIn && this.state.user) {
      const displayName = this.state.user.fullName || this.state.user.email?.split('@')[0] || 'User';
      container.innerHTML = `
        <button type="button" class="btn btn-secondary btn-sm" onclick="App.navigate('account')">
          👤 ${displayName}
        </button>
        <button type="button" class="btn btn-secondary btn-sm" onclick="App.logout()">
          ${this.t('btnSignOut')}
        </button>
      `;
    } else {
      container.innerHTML = `
        <button type="button" class="btn btn-secondary btn-sm" onclick="App.openAuthModal('login')">${this.t('btnSignIn')}</button>
        <button type="button" class="btn btn-primary btn-sm" onclick="App.openAuthModal('register')">${this.t('btnCreateAccount')}</button>
      `;
    }
  },

  handleMobileUserClick() {
    if (this.state.token) {
      this.navigate('account');
    } else {
      this.openAuthModal('login');
    }
  },

  openAuthModal(tab = 'login') {
    const modal = document.getElementById('auth-modal');
    if (modal) {
      modal.classList.add('active');
      this.switchAuthTab(tab);
    }
  },

  closeAuthModal() {
    const modal = document.getElementById('auth-modal');
    if (modal) modal.classList.remove('active');
  },

  switchAuthTab(tab) {
    const tabLogin = document.getElementById('tab-auth-login');
    const tabRegister = document.getElementById('tab-auth-register');
    const panelLogin = document.getElementById('auth-panel-login');
    const panelRegister = document.getElementById('auth-panel-register');

    const errLogin = document.getElementById('login-error');
    const errReg = document.getElementById('register-error');
    if (errLogin) errLogin.style.display = 'none';
    if (errReg) errReg.style.display = 'none';

    if (tab === 'login') {
      if (tabLogin) tabLogin.classList.add('active');
      if (tabRegister) tabRegister.classList.remove('active');
      if (panelLogin) panelLogin.style.display = 'block';
      if (panelRegister) panelRegister.style.display = 'none';
    } else {
      if (tabLogin) tabLogin.classList.remove('active');
      if (tabRegister) tabRegister.classList.add('active');
      if (panelLogin) panelLogin.style.display = 'none';
      if (panelRegister) panelRegister.style.display = 'block';
    }
  },

  togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    if (input) {
      input.type = input.type === 'password' ? 'text' : 'password';
    }
  },

  fillDemoLogin(email, password) {
    const emailInp = document.getElementById('login-email');
    const pwdInp = document.getElementById('login-password');
    if (emailInp) emailInp.value = email;
    if (pwdInp) pwdInp.value = password;
  },

  async handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email')?.value.trim();
    const password = document.getElementById('login-password')?.value;
    const errEl = document.getElementById('login-error');
    const submitBtn = document.getElementById('btn-login-submit');

    if (errEl) errEl.style.display = 'none';

    if (!email || !password) {
      if (errEl) {
        errEl.innerText = this.state.lang === 'hi' 
          ? 'कृपया अपना ईमेल और पासवर्ड दोनों दर्ज करें।' 
          : 'Please enter both your email and password.';
        errEl.style.display = 'block';
      }
      return;
    }

    if (submitBtn) submitBtn.disabled = true;

    try {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.message || 'Email or password is incorrect. Please try again.');
      }

      const data = await res.json();
      this.setSession(data);
      this.closeAuthModal();
      this.showToast(this.state.lang === 'hi' ? 'सफलतापूर्वक लॉग इन हुआ!' : 'Successfully signed in!', 'success');
      this.navigate('home');

    } catch (err) {
      if (errEl) {
        errEl.innerText = err.message;
        errEl.style.display = 'block';
      }
    } finally {
      if (submitBtn) submitBtn.disabled = false;
    }
  },

  async handleRegister(e) {
    e.preventDefault();
    const fullName = document.getElementById('reg-name')?.value.trim();
    const email = document.getElementById('reg-email')?.value.trim();
    const password = document.getElementById('reg-password')?.value;
    const errEl = document.getElementById('register-error');
    const submitBtn = document.getElementById('btn-register-submit');

    if (errEl) errEl.style.display = 'none';

    if (!fullName || !email || !password) {
      if (errEl) {
        errEl.innerText = this.state.lang === 'hi'
          ? 'कृपया सभी आवश्यक फ़ील्ड भरें।'
          : 'Please fill in all required fields.';
        errEl.style.display = 'block';
      }
      return;
    }

    if (password.length < 6) {
      if (errEl) {
        errEl.innerText = this.state.lang === 'hi'
          ? 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।'
          : 'Password must be at least 6 characters.';
        errEl.style.display = 'block';
      }
      return;
    }

    if (submitBtn) submitBtn.disabled = true;

    try {
      // Role is always ROLE_USER for public registration
      const res = await fetch(`${API_BASE}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName, email, password, role: 'ROLE_USER' })
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.message || 'Registration failed. Please check your information.');
      }

      const data = await res.json();
      this.setSession(data);
      this.closeAuthModal();
      this.showToast(this.state.lang === 'hi' ? 'खाता सफलतापूर्वक बन गया!' : 'Account successfully created!', 'success');
      this.navigate('home');

    } catch (err) {
      if (errEl) {
        errEl.innerText = err.message;
        errEl.style.display = 'block';
      }
    } finally {
      if (submitBtn) submitBtn.disabled = false;
    }
  },

  setSession(authData) {
    this.state.token = authData.token;
    this.state.user = {
      email: authData.email,
      fullName: authData.fullName,
      role: authData.role
    };
    localStorage.setItem('fs_token', authData.token);
    localStorage.setItem('fs_user', JSON.stringify(this.state.user));
    this.updateAuthUI(true);
  },

  logout(showNotice = true) {
    this.state.token = null;
    this.state.user = null;
    localStorage.removeItem('fs_token');
    localStorage.removeItem('fs_user');
    this.updateAuthUI(false);
    if (showNotice) {
      this.showToast(this.state.lang === 'hi' ? 'आप लॉग आउट हो चुके हैं।' : 'You have been signed out.', 'info');
    }
    this.navigate('home');
  },

  // ---------------------------------------------------------------------------
  // PROFILE & ACCOUNT DETAILS
  // ---------------------------------------------------------------------------
  async loadProfile() {
    const nameEl = document.getElementById('acc-name');
    const emailEl = document.getElementById('acc-email');
    const txnsEl = document.getElementById('acc-txns-count');
    const dateEl = document.getElementById('acc-created-date');

    if (!this.state.token) return;

    try {
      const res = await fetch(`${API_BASE}/users/profile`, {
        headers: this.getAuthHeaders()
      });
      if (res.ok) {
        const prof = await res.json();
        if (nameEl) nameEl.innerText = prof.fullName || 'User';
        if (emailEl) emailEl.innerText = prof.email || '-';
        if (txnsEl) txnsEl.innerText = prof.totalTransactions || '0';
        if (dateEl) {
          dateEl.innerText = prof.createdAt 
            ? new Date(prof.createdAt).toLocaleDateString(undefined, { month: 'long', year: 'numeric' })
            : 'Recent';
        }
      }
    } catch (e) {
      console.warn('Profile load error:', e);
    }
  },

  // ---------------------------------------------------------------------------
  // ADMIN DASHBOARD & AUDIT
  // ---------------------------------------------------------------------------
  async loadAdminData() {
    if (this.state.user?.role !== 'ROLE_ADMIN') return;

    try {
      const [statsRes, txnsRes] = await Promise.all([
        fetch(`${API_BASE}/admin/statistics`, { headers: this.getAuthHeaders() }),
        fetch(`${API_BASE}/admin/transactions?size=8`, { headers: this.getAuthHeaders() })
      ]);

      if (statsRes.ok) {
        const stats = await statsRes.json();
        const usersEl = document.getElementById('adm-users');
        const txnsEl = document.getElementById('adm-txns');
        const safeEl = document.getElementById('adm-safe');
        const warnEl = document.getElementById('adm-warnings');

        if (usersEl) usersEl.innerText = stats.totalUsers || '0';
        if (txnsEl) txnsEl.innerText = stats.totalTransactions || '0';
        if (safeEl) safeEl.innerText = stats.approvedTransactions || '0';
        if (warnEl) warnEl.innerText = (stats.blockedTransactions || 0) + (stats.flaggedTransactions || 0);
      }

      if (txnsRes.ok) {
        const page = await txnsRes.json();
        const tbody = document.getElementById('admin-txns-tbody');
        if (tbody) {
          tbody.innerHTML = '';
          (page.content || []).forEach(txn => {
            const tr = document.createElement('tr');
            const statusClass = txn.status === 'APPROVED' ? 'badge-safe' : (txn.status === 'BLOCKED' ? 'badge-high' : 'badge-medium');
            tr.innerHTML = `
              <td class="mono">${txn.transactionReference}</td>
              <td>${txn.userFullName || txn.userEmail || '-'}</td>
              <td class="mono">$${txn.amount?.toFixed(2)}</td>
              <td>${txn.merchantCategory}</td>
              <td><span class="badge ${statusClass}">${txn.status}</span></td>
            `;
            tbody.appendChild(tr);
          });
        }
      }
    } catch (e) {
      console.error('Admin data fetch error:', e);
    }
  },

  closeDetailModal() {
    const modal = document.getElementById('detail-modal');
    if (modal) modal.classList.remove('active');
  },

  // ---------------------------------------------------------------------------
  // TOAST NOTIFICATIONS
  // ---------------------------------------------------------------------------
  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icon = type === 'success' ? '✓' : (type === 'error' ? '✕' : 'ℹ');
    toast.innerHTML = `<span aria-hidden="true">${icon}</span> <span>${message}</span>`;

    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }
};

// Start application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
